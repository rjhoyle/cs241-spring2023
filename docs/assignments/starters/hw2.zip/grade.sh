#!/bin/sh

# variable to target correct README filename
README="README"
if (find README.md 2>/dev/null); then
    README="README.md"
fi

echo "printing README**********************************"
cat $README
echo
echo "Makefile*****************************************"
cat Makefile
echo "making clean*************************************"
make clean
echo "making*******************************************"
make
echo "running hello************************************"
./hello
cat hello.c

# updated rot128
echo "running rot128 with README***********************************"
echo "Should be nothing above!"
./rot128 < $README > testout
./rot128 < testout > finalout
echo "checking diff************************************"
diff $README finalout
echo "\n\n"

# remove testing files
rm testout
rm finalout

# rot128 extracredit
echo "comparing rot128 to rot128 with input***********************************"
echo "Should be different if they attempted extra credit (and got the first part right)!"
./rot128 20 < $README > testout
./rot128 < $README > finalout
echo "checking diff************************************"
diff testout finalout
echo "\n\n"

echo "comparing rot128 to rot128 with input***********************************"
echo "Should be the same if extra credit is successfully implemented."
./rot128 20 < $README > testout
./rot128 236 < testout > finalout
echo "checking diff************************************"
diff $README finalout
echo "\n\n"

# remove testing files
rm testout
rm finalout

echo "abc123" >> _test1
echo "568" >> _test2

echo "running diamond**********************************"
./diamond < _test1
echo "\n\nShould be 1"
./diamond < _test2
echo "\n\nShould be 5"

# remove testing files
rm _test1
rm _test2

echo "-5" >> _test1
echo "-1" >> _test2

echo "running diamond EXTRA CREDIT**********************************"
./diamond < _test1
echo "\n\nInput -5"
./diamond < _test2
echo "\n\nInput -1"
