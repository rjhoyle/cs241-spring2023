#!/bin/sh

if [ ! -e README ]
then
    echo README not found
fi;


cat README

echo
echo Press RETURN to continue

read INPUT

if [ ! -e diskhogger.sh ]
then
    echo diskhogger.sh not found
fi;

if [ ! -e modified.sh ]
then
    echo modified.sh not found
fi;

if [ ! -e data_file_analysis ]
then
    echo data_file_analysis not found
fi;

echo Grading complete
